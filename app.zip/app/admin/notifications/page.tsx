"use client";

import { useEffect, useState } from "react";

import {
  addNotification,
  deleteNotification,
  getNotifications,
} from "../../services/notificationService";

import {
  getOrders,
  updateOrderStatus,
} from "../../services/orderService";

type Order = {
  id: string;
  customer?: {
    name?: string;
    phone?: string;
    address?: string;
    city?: string;
    pincode?: string;
  };
  total?: number;
  payment?: string;
  paymentMethod?: string;
  status?: string;
  createdAt?: any;
};

type Notification = {
  id: string;
  title?: string;
  message?: string;
  orderId?: string;
  type?: string;
  read?: boolean;
  createdAt?: any;
};

const STATUS_LIST = [
  "Pending",
  "Confirmed",
  "Preparing",
  "Out for Delivery",
  "Delivered",
  "Cancelled",
];

export default function AdminNotificationsPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState<
    Notification[]
  >([]);

  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");

  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);

  // ==========================================
  // LOAD DATA
  // ==========================================

  const loadData = async () => {
    try {
      setLoading(true);

      const [orderData, notificationData] =
        await Promise.all([
          getOrders(),
          getNotifications(),
        ]);

      setOrders(
        (orderData as Order[]).sort(
          (a, b) =>
            getDateValue(b.createdAt) -
            getDateValue(a.createdAt)
        )
      );

      setNotifications(
        (notificationData as Notification[]).sort(
          (a, b) =>
            getDateValue(b.createdAt) -
            getDateValue(a.createdAt)
        )
      );
    } catch (error) {
      console.error(
        "Notification page loading error:",
        error
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    const timer = setInterval(() => {
      loadData();
    }, 10000);

    return () => clearInterval(timer);
  }, []);

  // ==========================================
  // PENDING ORDERS
  // ==========================================

  const pendingOrders = orders.filter(
    (order) =>
      normalizeStatus(order.status) === "Pending"
  );

  // ==========================================
  // CHANGE ORDER STATUS
  // ==========================================

  const changeStatus = async (
    orderId: string,
    status: string
  ) => {
    try {
      await updateOrderStatus(
        orderId,
        status
      );

      await loadData();
    } catch (error) {
      console.error(
        "Status update error:",
        error
      );

      alert(
        "Order status update failed."
      );
    }
  };

  // ==========================================
  // CREATE NOTIFICATION
  // ==========================================

  const sendNotification = async () => {
    if (!title.trim()) {
      alert("Title required.");
      return;
    }

    if (!message.trim()) {
      alert("Message required.");
      return;
    }

    try {
      setSending(true);

      await addNotification(
        title.trim(),
        message.trim()
      );

      setTitle("");
      setMessage("");

      await loadData();

      alert(
        "Notification sent successfully."
      );
    } catch (error) {
      console.error(error);

      alert(
        "Notification send failed."
      );
    } finally {
      setSending(false);
    }
  };

  // ==========================================
  // DELETE NOTIFICATION
  // ==========================================

  const removeNotification = async (
    id: string
  ) => {
    const confirmDelete =
      window.confirm(
        "Delete this notification?"
      );

    if (!confirmDelete) {
      return;
    }

    try {
      await deleteNotification(id);

      setNotifications((current) =>
        current.filter(
          (item) => item.id !== id
        )
      );
    } catch (error) {
      console.error(error);

      alert(
        "Notification delete failed."
      );
    }
  };

  // ==========================================
  // OPEN ORDER
  // ==========================================

  const openOrder = (
    orderId: string
  ) => {
    window.location.href =
      `/admin/orders/${orderId}`;
  };

  return (
    <main className="min-h-screen bg-slate-100 p-4 text-slate-900 md:p-8">

      <div className="mx-auto max-w-7xl">

        {/* HEADER */}

        <section className="rounded-3xl bg-white p-6 shadow-sm">

          <p className="text-xs font-black uppercase tracking-widest text-yellow-600">
            NIGHT NOW ADMIN
          </p>

          <h1 className="mt-1 text-3xl font-black">
            Notifications
          </h1>

          <p className="mt-2 text-sm text-slate-500">
            Orders aur notifications manage karein.
          </p>

        </section>

        {/* =====================================
            PENDING ORDERS
        ====================================== */}

        <section className="mt-5 rounded-3xl border-2 border-red-200 bg-white p-5 shadow-sm">

          <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">

            <div>

              <h2 className="text-2xl font-black text-red-700">
                🔴 New Orders Pending
              </h2>

              <p className="mt-1 text-xs text-slate-500">
                Customer ke naye pending orders.
              </p>

            </div>

            <div className="rounded-full bg-red-600 px-4 py-2 text-xs font-black text-white">
              {pendingOrders.length} Pending
            </div>

          </div>

          {loading ? (

            <div className="mt-5 rounded-2xl bg-slate-50 p-8 text-center font-bold text-slate-500">
              Loading orders...
            </div>

          ) : pendingOrders.length === 0 ? (

            <div className="mt-5 rounded-2xl bg-green-50 p-8 text-center">

              <div className="text-4xl">
                ✅
              </div>

              <p className="mt-2 font-black text-green-700">
                No Pending Orders
              </p>

            </div>

          ) : (

            <div className="mt-5 space-y-4">

              {pendingOrders.map(
                (order) => (

                  <div
                    key={order.id}
                    className="rounded-2xl border border-red-200 bg-red-50 p-4"
                  >

                    <div className="flex flex-col justify-between gap-4 lg:flex-row">

                      {/* ORDER INFO */}

                      <div className="min-w-0 flex-1">

                        <div className="flex flex-wrap items-center gap-2">

                          <span className="rounded-full bg-yellow-400 px-3 py-1 text-[10px] font-black text-black">
                            🟡 PENDING
                          </span>

                          <span className="text-xs font-black text-slate-500">
                            #{order.id}
                          </span>

                        </div>

                        <h3 className="mt-3 text-xl font-black">
                          {order.customer?.name ||
                            "Customer"}
                        </h3>

                        {order.customer?.phone ? (
                          <a
                            href={`tel:${order.customer.phone}`}
                            onClick={(event) =>
                              event.stopPropagation()
                            }
                            className="mt-1 inline-block text-sm font-bold text-blue-600"
                          >
                            📞{" "}
                            {order.customer.phone}
                          </a>
                        ) : null}

                        <p className="mt-3 text-sm text-slate-600">
                          📍{" "}
                          {order.customer?.address ||
                            "Address not available"}
                        </p>

                        {order.customer?.city ? (
                          <p className="text-xs text-slate-500">
                            {order.customer.city}
                            {order.customer.pincode
                              ? ` - ${order.customer.pincode}`
                              : ""}
                          </p>
                        ) : null}

                        <p className="mt-2 text-xs text-slate-400">
                          {formatDate(
                            order.createdAt
                          )}
                        </p>

                      </div>

                      {/* ORDER ACTIONS */}

                      <div className="flex shrink-0 flex-col gap-2">

                        <div className="text-2xl font-black text-green-600">
                          ₹
                          {Number(
                            order.total || 0
                          )}
                        </div>

                        <div className="rounded-xl bg-white px-3 py-2 text-xs font-black text-slate-700">
                          💳{" "}
                          {order.paymentMethod ||
                            order.payment ||
                            "COD"}
                        </div>

                        <select
                          value={normalizeStatus(
                            order.status
                          )}
                          onChange={(event) =>
                            changeStatus(
                              order.id,
                              event.target.value
                            )
                          }
                          className={`rounded-xl border px-3 py-2 text-xs font-black outline-none ${getStatusClass(
                            order.status
                          )}`}
                        >
                          {STATUS_LIST.map(
                            (status) => (
                              <option
                                key={status}
                                value={status}
                              >
                                {status}
                              </option>
                            )
                          )}
                        </select>

                        <button
                          type="button"
                          onClick={() =>
                            openOrder(
                              order.id
                            )
                          }
                          className="rounded-xl bg-black px-5 py-3 text-xs font-black text-white"
                        >
                          View Order →
                        </button>

                      </div>

                    </div>

                  </div>

                )
              )}

            </div>

          )}

        </section>

        {/* =====================================
            CREATE NOTIFICATION
        ====================================== */}

        <section className="mt-5 rounded-3xl bg-white p-6 shadow-sm">

          <h2 className="text-xl font-black">
            Create Notification
          </h2>

          <div className="mt-5 space-y-4">

            <input
              type="text"
              value={title}
              onChange={(event) =>
                setTitle(
                  event.target.value
                )
              }
              placeholder="Notification title"
              className="h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 outline-none focus:border-yellow-400"
            />

            <textarea
              value={message}
              onChange={(event) =>
                setMessage(
                  event.target.value
                )
              }
              rows={4}
              placeholder="Notification message"
              className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-yellow-400"
            />

            <button
              type="button"
              onClick={
                sendNotification
              }
              disabled={sending}
              className="rounded-2xl bg-yellow-400 px-6 py-3 font-black text-black disabled:opacity-50"
            >
              {sending
                ? "Sending..."
                : "🔔 Send Notification"}
            </button>

          </div>

        </section>

        {/* =====================================
            ALL NOTIFICATIONS
        ====================================== */}

        <section className="mt-5 rounded-3xl bg-white p-6 shadow-sm">

          <div className="flex items-center justify-between">

            <div>

              <h2 className="text-xl font-black">
                All Notifications
              </h2>

              <p className="mt-1 text-xs text-slate-500">
                Order aur general notifications.
              </p>

            </div>

            <span className="rounded-full bg-slate-100 px-3 py-2 text-xs font-black">
              {notifications.length}
            </span>

          </div>

          <div className="mt-5 space-y-3">

            {notifications.length === 0 ? (

              <div className="rounded-2xl bg-slate-50 p-8 text-center text-sm font-bold text-slate-500">
                No notifications.
              </div>

            ) : (

              notifications.map(
                (notification) => (

                  <div
                    key={notification.id}
                    className={`rounded-2xl border p-4 ${
                      notification.read === false
                        ? "border-yellow-300 bg-yellow-50"
                        : "border-slate-200 bg-slate-50"
                    }`}
                  >

                    <div className="flex flex-col justify-between gap-4 sm:flex-row">

                      <div className="min-w-0 flex-1">

                        <div className="flex flex-wrap items-center gap-2">

                          <h3 className="font-black">
                            {notification.type ===
                              "new-order" ||
                            notification.orderId
                              ? "🔔"
                              : "📢"}{" "}
                            {notification.title ||
                              "Notification"}
                          </h3>

                          {notification.read ===
                            false ? (
                            <span className="rounded-full bg-red-600 px-2 py-1 text-[8px] font-black text-white">
                              NEW
                            </span>
                          ) : null}

                        </div>

                        <p className="mt-2 text-sm text-slate-600">
                          {notification.message ||
                            ""}
                        </p>

                        {notification.orderId ? (
                          <p className="mt-2 text-xs font-black text-slate-500">
                            Order #
                            {
                              notification.orderId
                            }
                          </p>
                        ) : null}

                        <p className="mt-2 text-[10px] text-slate-400">
                          {formatDate(
                            notification.createdAt
                          )}
                        </p>

                      </div>

                      <div className="flex shrink-0 flex-wrap gap-2">

                        {notification.orderId ? (
                          <button
                            type="button"
                            onClick={() =>
                              openOrder(
                                notification.orderId!
                              )
                            }
                            className="rounded-xl bg-black px-4 py-2 text-xs font-black text-white"
                          >
                            Open Order →
                          </button>
                        ) : null}

                        <button
                          type="button"
                          onClick={() =>
                            removeNotification(
                              notification.id
                            )
                          }
                          className="rounded-xl bg-red-50 px-4 py-2 text-xs font-black text-red-600"
                        >
                          Delete
                        </button>

                      </div>

                    </div>

                  </div>

                )
              )

            )}

          </div>

        </section>

      </div>

    </main>
  );
}

// ==========================================
// STATUS
// ==========================================

function normalizeStatus(
  status?: string
) {
  if (!status) {
    return "Pending";
  }

  if (status === "Packed") {
    return "Confirmed";
  }

  return status;
}

function getStatusClass(
  status?: string
) {
  const value =
    normalizeStatus(status);

  if (value === "Pending") {
    return "border-yellow-300 bg-yellow-100 text-yellow-800";
  }

  if (value === "Confirmed") {
    return "border-blue-300 bg-blue-100 text-blue-800";
  }

  if (value === "Preparing") {
    return "border-purple-300 bg-purple-100 text-purple-800";
  }

  if (
    value === "Out for Delivery"
  ) {
    return "border-orange-300 bg-orange-100 text-orange-800";
  }

  if (value === "Delivered") {
    return "border-green-300 bg-green-100 text-green-800";
  }

  if (value === "Cancelled") {
    return "border-red-300 bg-red-100 text-red-800";
  }

  return "border-slate-300 bg-white text-slate-700";
}

// ==========================================
// DATE
// ==========================================

function getDateValue(
  value: any
) {
  if (!value) {
    return 0;
  }

  if (
    typeof value.toMillis ===
    "function"
  ) {
    return value.toMillis();
  }

  if (
    typeof value.toDate ===
    "function"
  ) {
    return value
      .toDate()
      .getTime();
  }

  if (value.seconds) {
    return (
      value.seconds * 1000
    );
  }

  const result =
    new Date(value).getTime();

  return Number.isNaN(result)
    ? 0
    : result;
}

function formatDate(
  value: any
) {
  const time =
    getDateValue(value);

  if (!time) {
    return "-";
  }

  return new Date(
    time
  ).toLocaleString("en-IN");
}