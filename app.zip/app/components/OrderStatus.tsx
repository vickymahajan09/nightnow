"use client";

interface OrderStatusProps {
  status?: string;
}

const statuses = [
  "Pending",
  "Confirmed",
  "Preparing",
  "Out for Delivery",
  "Delivered",
];

export default function OrderStatus({
  status = "Pending",
}: OrderStatusProps) {
  const currentIndex =
    statuses.indexOf(
      status
    );

  return (
    <div className="mt-6">

      <h3 className="mb-5 text-lg font-bold">
        Order Status
      </h3>

      <div className="space-y-4">

        {statuses.map(
          (
            item,
            index
          ) => {
            const completed =
              currentIndex >=
              index;

            const active =
              status === item;

            const config =
              getStatusConfig(
                item
              );

            return (
              <div
                key={item}
                className="flex items-center gap-4"
              >

                <div
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 text-sm font-black ${
                    active
                      ? config.active
                      : completed
                        ? config.completed
                        : "border-zinc-700 bg-zinc-800 text-zinc-500"
                  }`}
                >
                  {completed
                    ? "✓"
                    : index + 1}
                </div>

                <div>

                  <p
                    className={`font-bold ${
                      active
                        ? config.text
                        : completed
                          ? "text-white"
                          : "text-zinc-500"
                    }`}
                  >
                    {item}
                  </p>

                  {active && (
                    <p className="text-xs text-zinc-400">
                      Current order status
                    </p>
                  )}

                </div>

              </div>
            );
          }
        )}

      </div>

      {status ===
        "Cancelled" && (
        <div className="mt-5 rounded-xl border border-red-800 bg-red-950 p-4 text-red-400">

          <p className="font-bold">
            🔴 Order Cancelled
          </p>

          <p className="mt-1 text-sm">
            This order has been cancelled.
          </p>

        </div>
      )}

    </div>
  );
}

function getStatusConfig(
  status: string
) {
  switch (status) {
    case "Pending":
      return {
        active:
          "border-yellow-400 bg-yellow-400 text-black",
        completed:
          "border-yellow-400 bg-yellow-400 text-black",
        text:
          "text-yellow-400",
      };

    case "Confirmed":
      return {
        active:
          "border-blue-500 bg-blue-500 text-white",
        completed:
          "border-blue-500 bg-blue-500 text-white",
        text:
          "text-blue-400",
      };

    case "Preparing":
      return {
        active:
          "border-purple-500 bg-purple-500 text-white",
        completed:
          "border-purple-500 bg-purple-500 text-white",
        text:
          "text-purple-400",
      };

    case "Out for Delivery":
      return {
        active:
          "border-orange-500 bg-orange-500 text-white",
        completed:
          "border-orange-500 bg-orange-500 text-white",
        text:
          "text-orange-400",
      };

    case "Delivered":
      return {
        active:
          "border-green-500 bg-green-500 text-white",
        completed:
          "border-green-500 bg-green-500 text-white",
        text:
          "text-green-400",
      };

    default:
      return {
        active:
          "border-zinc-500 bg-zinc-500 text-white",
        completed:
          "border-zinc-500 bg-zinc-500 text-white",
        text:
          "text-zinc-400",
      };
  }
}